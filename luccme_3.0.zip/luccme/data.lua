data{
	file = "cs_continuous.tview",
	summary = "",
	source = "",
	attributes = {},  -- optional
	types = {},       -- optional
	description = {}, -- optional
	reference = ""    -- optional
}

data{
	file = "cs_discrete.tview",
	summary = "",
	source = "",
	attributes = {},  -- optional
	types = {},       -- optional
	description = {}, -- optional
	reference = ""    -- optional
}

data{
	file = "csAC.shp",
	summary = "",
	source = "",
	attributes = {},  -- optional
	types = {},       -- optional
	description = {}, -- optional
	reference = ""    -- optional
}

data{
	file = "csAC_2009.shp",
	summary = "",
	source = "",
	attributes = {},  -- optional
	types = {},       -- optional
	description = {}, -- optional
	reference = ""    -- optional
}

data{
	file = "csAC_cenarioA_2020.shp",
	summary = "",
	source = "",
	attributes = {},  -- optional
	types = {},       -- optional
	description = {}, -- optional
	reference = ""    -- optional
}

data{
	file = "csrb.shp",
	summary = "",
	source = "",
	attributes = {},  -- optional
	types = {},       -- optional
	description = {}, -- optional
	reference = ""    -- optional
}

data{
	file = "csrb_2009.shp",
	summary = "",
	source = "",
	attributes = {},  -- optional
	types = {},       -- optional
	description = {}, -- optional
	reference = ""    -- optional
}

data{
	file = "csrb_cenarioA_2020.shp",
	summary = "",
	source = "",
	attributes = {},  -- optional
	types = {},       -- optional
	description = {}, -- optional
	reference = ""    -- optional
}
